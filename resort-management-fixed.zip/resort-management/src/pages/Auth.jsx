import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Sparkles, BedDouble, Eye, EyeOff } from 'lucide-react';

export default function Auth() {
  const { signIn, user } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (user) navigate('/'); }, [user, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setTimeout(() => {
      const result = signIn(email, password);
      if (result.error) { setError(result.error); setLoading(false); }
      else navigate('/');
    }, 500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="orb bg-indigo-600 w-96 h-96 -top-48 -right-48 opacity-10" />
      <div className="orb bg-amber-500 w-72 h-72 -bottom-36 -left-36 opacity-10" />
      <div className="orb bg-purple-600 w-64 h-64 top-1/2 left-1/3 opacity-5" />

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-gradient-to-br from-indigo-600 to-amber-500 shadow-xl shadow-indigo-600/30 mb-4">
            <BedDouble className="h-8 w-8 text-white" />
          </div>
          <h1 className="font-display text-3xl font-bold text-white">Resort Manager</h1>
          <p className="text-slate-400 mt-1 text-sm">Professional Room Management System</p>
        </div>

        {/* Card */}
        <div className="card p-8">
          <h2 className="text-xl font-semibold text-white mb-6">Sign In</h2>

          {error && (
            <div className="mb-4 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Email Address</label>
              <input
                type="email"
                className="input-field"
                placeholder="admin@resort.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  className="input-field pr-12"
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full justify-center py-3 mt-2 disabled:opacity-50"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
              ) : (
                <>
                  <Sparkles className="h-4 w-4" /> Sign In
                </>
              )}
            </button>
          </form>

          {/* Demo credentials */}
          <div className="mt-6 pt-6 border-t border-slate-700/50">
            <p className="text-xs text-slate-500 mb-3 font-medium uppercase tracking-wider">Demo Credentials</p>
            <div className="space-y-2">
              {[
                { role: 'Admin', email: 'admin@resort.com', password: 'admin123', color: 'indigo' },
                { role: 'Staff', email: 'staff@resort.com', password: 'staff123', color: 'emerald' },
              ].map(cred => (
                <button
                  key={cred.role}
                  onClick={() => { setEmail(cred.email); setPassword(cred.password); }}
                  className="w-full text-left px-3 py-2 rounded-lg bg-slate-700/30 hover:bg-slate-700/60 border border-slate-600/50 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-semibold text-${cred.color}-400 uppercase`}>{cred.role}</span>
                    <span className="text-xs text-slate-500">{cred.email}</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">Password: {cred.password}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
