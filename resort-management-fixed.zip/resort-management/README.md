# Resort Room Management System

A full-featured web application for managing resort room bookings, built as a Web Programming Final Semester Project.

## 🏨 Features

### Admin Access
- **Dashboard** — Full revenue metrics, occupancy stats, profit/loss, 7-day revenue chart
- **Rooms** — Add, edit, delete rooms (Standard → Presidential categories)
- **Bookings** — Create, edit, delete bookings with receipt printing
- **Calendar** — Visual monthly booking calendar
- **Customers** — Full guest management with booking history
- **Expenses** — Add, edit, delete expenses with category breakdown
- **User Management** — Create staff accounts, assign/change roles

### Staff Access
- **Dashboard** — Occupancy stats and recent bookings (no financial data)
- **Rooms** — View only (no add/edit/delete)
- **Bookings** — Create and edit bookings (no delete)
- **Calendar** — Full calendar view
- **Customers** — View and add customers
- **Expenses** — View only (no add/edit/delete)

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm or bun

### Installation

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

### Demo Login Credentials

| Role  | Email                    | Password       |
|-------|--------------------------|----------------|
| Admin | admin@resort.com         | admin123       |
| Staff | staff@resort.com         | staff123       |
| Staff | reception@resort.com     | reception123   |

## 🛠️ Tech Stack

| Layer     | Technology                              |
|-----------|-----------------------------------------|
| Frontend  | HTML5, React 18, React Router v6        |
| Styling   | Tailwind CSS                            |
| Charts    | Recharts                                |
| Icons     | Lucide React                            |
| Date Util | date-fns                                |
| Build     | Vite                                    |
| Storage   | localStorage (mock database)            |

## 📁 Project Structure

```
src/
├── contexts/
│   └── AuthContext.jsx        # Authentication & role management
├── lib/
│   └── store.js               # LocalStorage data store (mock DB)
├── components/
│   ├── layout/
│   │   └── MainLayout.jsx     # Sidebar + app shell
│   └── bookings/
│       └── BookingReceipt.jsx # Printable booking receipt
├── pages/
│   ├── Auth.jsx               # Login page
│   ├── Dashboard.jsx          # Main dashboard
│   ├── Rooms.jsx              # Room management
│   ├── Bookings.jsx           # Bookings list
│   ├── NewBooking.jsx         # Create booking
│   ├── EditBooking.jsx        # Edit booking
│   ├── Calendar.jsx           # Monthly calendar
│   ├── Customers.jsx          # Customer management
│   ├── Expenses.jsx           # Expense tracking
│   └── UserManagement.jsx     # User & role management (Admin only)
└── App.jsx                    # Routing & auth guards
```

## 🏗️ Architecture

- **Authentication**: Context-based auth with role (admin/staff) stored in localStorage
- **Role-based Access Control**: Admin and Staff routes protected at both router and component level
- **Data Store**: CRUD operations with localStorage persistence, seeded with sample resort data
- **Responsive Design**: Mobile-first layout with collapsible sidebar

## 📦 Build for Production

```bash
npm run build
npm run preview
```
