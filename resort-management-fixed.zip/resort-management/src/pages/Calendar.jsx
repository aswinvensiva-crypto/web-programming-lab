import { useState, useEffect } from 'react';
import { db } from '@/lib/store';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, isSameDay, addMonths, subMonths, parseISO } from 'date-fns';
import { ChevronLeft, ChevronRight, Circle } from 'lucide-react';

const STATUS_COLORS = {
  confirmed: '#6366f1',
  checked_in: '#22c55e',
  checked_out: '#64748b',
  cancelled: '#ef4444',
};

export default function Calendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [bookings, setBookings] = useState([]);
  const [selected, setSelected] = useState(null);
  const [dayBookings, setDayBookings] = useState([]);

  useEffect(() => { setBookings(db.bookings.getAll()); }, []);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Pad start
  const startPad = monthStart.getDay();
  const paddedDays = [...Array(startPad).fill(null), ...days];

  const getBookingsForDay = (day) => {
    if (!day) return [];
    return bookings.filter(b => {
      const checkIn = parseISO(b.checkInDate);
      const checkOut = parseISO(b.checkOutDate);
      return day >= checkIn && day < checkOut && b.bookingStatus !== 'cancelled';
    });
  };

  const handleDayClick = (day) => {
    if (!day) return;
    const bkgs = getBookingsForDay(day);
    setSelected(day);
    setDayBookings(bkgs);
  };

  const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">Calendar</h1>
          <p className="text-slate-400 text-sm mt-1">Room booking overview</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setCurrentMonth(m => subMonths(m, 1))} className="btn-secondary p-2">
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="text-white font-semibold min-w-36 text-center">{format(currentMonth, 'MMMM yyyy')}</span>
          <button onClick={() => setCurrentMonth(m => addMonths(m, 1))} className="btn-secondary p-2">
            <ChevronRight className="h-4 w-4" />
          </button>
          <button onClick={() => setCurrentMonth(new Date())} className="btn-secondary text-sm px-3">Today</button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-xs text-slate-400">
        {Object.entries(STATUS_COLORS).map(([s, c]) => (
          <span key={s} className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: c }} />
            {s.replace('_', ' ')}
          </span>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Grid */}
        <div className="lg:col-span-2 card p-4">
          {/* Day headers */}
          <div className="grid grid-cols-7 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
              <div key={d} className="text-center text-xs font-semibold text-slate-500 py-2">{d}</div>
            ))}
          </div>

          {/* Days */}
          <div className="grid grid-cols-7 gap-1">
            {paddedDays.map((day, idx) => {
              if (!day) return <div key={`pad-${idx}`} />;
              const dayBkgs = getBookingsForDay(day);
              const isSelected = selected && isSameDay(day, selected);
              const todayDay = isToday(day);
              return (
                <button
                  key={day.toISOString()}
                  onClick={() => handleDayClick(day)}
                  className={`relative min-h-[70px] p-1 rounded-xl text-left transition-all border ${
                    isSelected ? 'border-indigo-500 bg-indigo-500/10' :
                    todayDay ? 'border-amber-500/50 bg-amber-500/5' :
                    'border-transparent hover:border-slate-600 hover:bg-slate-700/30'
                  }`}
                >
                  <span className={`text-xs font-medium block mb-1 px-1 ${
                    todayDay ? 'text-amber-400 font-bold' :
                    isSameMonth(day, currentMonth) ? 'text-slate-300' : 'text-slate-600'
                  }`}>
                    {format(day, 'd')}
                  </span>
                  <div className="space-y-0.5">
                    {dayBkgs.slice(0, 3).map(b => (
                      <div key={b.id} className="text-xs px-1 py-0.5 rounded truncate"
                        style={{ background: STATUS_COLORS[b.bookingStatus] + '30', color: STATUS_COLORS[b.bookingStatus], fontSize: '10px' }}>
                        {b.room?.roomNumber} {b.customer?.name?.split(' ')[0]}
                      </div>
                    ))}
                    {dayBkgs.length > 3 && (
                      <div className="text-xs text-slate-500 px-1">+{dayBkgs.length - 3} more</div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Day Detail Panel */}
        <div className="card p-5">
          <h2 className="text-lg font-semibold text-white mb-4">
            {selected ? format(selected, 'EEEE, dd MMM yyyy') : 'Select a day'}
          </h2>

          {!selected && (
            <p className="text-slate-500 text-sm">Click on any date to see bookings for that day.</p>
          )}

          {selected && dayBookings.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              <Circle className="h-8 w-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No active bookings</p>
            </div>
          )}

          <div className="space-y-3">
            {dayBookings.map(b => (
              <div key={b.id} className="p-3 rounded-xl border border-slate-700/50 bg-slate-700/20 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white text-sm">{b.customer?.name}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                    style={{ background: STATUS_COLORS[b.bookingStatus] + '30', color: STATUS_COLORS[b.bookingStatus] }}>
                    {b.bookingStatus.replace('_', ' ')}
                  </span>
                </div>
                <div className="text-xs text-slate-400">
                  Room {b.room?.roomNumber} — {b.room?.roomName}
                </div>
                <div className="text-xs text-slate-500">
                  {format(parseISO(b.checkInDate), 'dd MMM')} → {format(parseISO(b.checkOutDate), 'dd MMM')} ({b.totalDays} nights)
                </div>
                <div className="text-xs font-medium text-emerald-400">{fmt(b.totalAmount)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Monthly Summary */}
      <div className="card p-5">
        <h2 className="text-lg font-semibold text-white mb-4">This Month Summary</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {Object.entries(STATUS_COLORS).map(([status, color]) => {
            const count = bookings.filter(b => {
              const checkIn = parseISO(b.checkInDate);
              return isSameMonth(checkIn, currentMonth) && b.bookingStatus === status;
            }).length;
            return (
              <div key={status} className="text-center p-3 rounded-xl bg-slate-700/30">
                <div className="text-xl font-bold" style={{ color }}>{count}</div>
                <div className="text-xs text-slate-400 mt-1 capitalize">{status.replace('_', ' ')}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
