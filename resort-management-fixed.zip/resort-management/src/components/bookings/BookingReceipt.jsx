import { format } from 'date-fns';
import { Printer, X, BedDouble, User, Calendar } from 'lucide-react';

const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

export default function BookingReceipt({ booking: b, onClose }) {
  const handlePrint = () => window.print();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm no-print" onClick={onClose} />
      <div className="relative bg-white text-slate-900 rounded-2xl shadow-2xl w-full max-w-md z-10 overflow-hidden">
        {/* Actions */}
        <div className="flex justify-between items-center px-6 py-3 bg-slate-100 no-print">
          <span className="text-sm font-medium text-slate-600">Booking Receipt</span>
          <div className="flex gap-2">
            <button onClick={handlePrint} className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-sm hover:bg-indigo-700 transition-colors">
              <Printer className="h-4 w-4" /> Print
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-500 hover:text-slate-700 rounded-lg">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="p-6" id="receipt">
          {/* Header */}
          <div className="text-center border-b border-slate-200 pb-5 mb-5">
            <div className="inline-flex items-center justify-center h-12 w-12 rounded-xl bg-indigo-600 mb-3">
              <BedDouble className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-slate-900">RESORT MANAGER</h1>
            <p className="text-slate-500 text-sm">Booking Confirmation Receipt</p>
            <div className="mt-2 text-xs text-slate-400">#{b.id.slice(0, 8).toUpperCase()}</div>
          </div>

          {/* Guest & Room */}
          <div className="grid grid-cols-2 gap-4 mb-5">
            <div className="bg-slate-50 rounded-xl p-3">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1"><User className="h-3 w-3" /> GUEST</div>
              <div className="font-semibold text-slate-900">{b.customer?.name}</div>
              <div className="text-sm text-slate-600">{b.customer?.phone}</div>
              {b.customer?.email && <div className="text-xs text-slate-500">{b.customer?.email}</div>}
            </div>
            <div className="bg-slate-50 rounded-xl p-3">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1"><BedDouble className="h-3 w-3" /> ROOM</div>
              <div className="font-semibold text-slate-900">Room {b.room?.roomNumber}</div>
              <div className="text-sm text-slate-600">{b.room?.roomName}</div>
              <div className="text-xs text-slate-500">{fmt(b.room?.pricePerDay)}/day</div>
            </div>
          </div>

          {/* Dates */}
          <div className="bg-indigo-50 rounded-xl p-4 mb-5">
            <div className="flex items-center gap-1.5 text-xs text-indigo-500 mb-3"><Calendar className="h-3 w-3" /> STAY DETAILS</div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <div className="text-xs text-slate-500 mb-0.5">Check-in</div>
                <div className="font-semibold text-slate-900 text-sm">{format(new Date(b.checkInDate + 'T00:00:00'), 'dd MMM yyyy')}</div>
              </div>
              <div className="border-x border-indigo-200">
                <div className="text-xs text-slate-500 mb-0.5">Duration</div>
                <div className="font-bold text-indigo-600 text-lg">{b.totalDays}</div>
                <div className="text-xs text-slate-500">night{b.totalDays > 1 ? 's' : ''}</div>
              </div>
              <div>
                <div className="text-xs text-slate-500 mb-0.5">Check-out</div>
                <div className="font-semibold text-slate-900 text-sm">{format(new Date(b.checkOutDate + 'T00:00:00'), 'dd MMM yyyy')}</div>
              </div>
            </div>
          </div>

          {/* Billing */}
          <div className="space-y-2 text-sm mb-5">
            <div className="flex justify-between text-slate-600">
              <span>Room charges ({b.totalDays} × {fmt(b.room?.pricePerDay)})</span>
              <span>{fmt(b.baseAmount)}</span>
            </div>
            {b.taxPercentage > 0 && (
              <div className="flex justify-between text-slate-600">
                <span>Tax ({b.taxPercentage}%)</span>
                <span>{fmt(b.taxAmount)}</span>
              </div>
            )}
            <div className="border-t border-slate-200 pt-2 flex justify-between font-bold text-slate-900">
              <span>Total Amount</span>
              <span>{fmt(b.totalAmount)}</span>
            </div>
            <div className="flex justify-between text-emerald-600 font-medium">
              <span>Advance Paid</span>
              <span>- {fmt(b.advancePaid)}</span>
            </div>
            <div className="flex justify-between font-bold text-base border-t border-slate-200 pt-2">
              <span className={b.pendingAmount > 0 ? 'text-amber-600' : 'text-emerald-600'}>
                {b.pendingAmount > 0 ? 'Balance Due' : 'Fully Paid'}
              </span>
              <span className={b.pendingAmount > 0 ? 'text-amber-600' : 'text-emerald-600'}>
                {fmt(b.pendingAmount)}
              </span>
            </div>
          </div>

          {/* Status & Notes */}
          <div className="flex justify-between items-start text-xs text-slate-500 pt-4 border-t border-slate-200">
            <div>
              <div>Booking: <span className="capitalize font-medium text-slate-700">{b.bookingStatus.replace('_', ' ')}</span></div>
              <div>Payment: <span className="capitalize font-medium text-slate-700">{b.paymentStatus}</span></div>
              {b.notes && <div className="mt-1">Note: {b.notes}</div>}
            </div>
            <div className="text-right">
              <div>Issued: {format(new Date(b.createdAt), 'dd MMM yyyy')}</div>
              <div className="mt-1 text-indigo-400">Thank you for staying!</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
