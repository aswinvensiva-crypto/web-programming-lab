import { useState, useEffect } from 'react';
import { db } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Trash2, Edit, Receipt, TrendingDown, Filter } from 'lucide-react';
import { format, startOfMonth, endOfMonth, isSameMonth } from 'date-fns';

const CATEGORIES = [
  { value: 'housekeeping', label: 'Housekeeping', color: 'text-blue-400' },
  { value: 'food_beverage', label: 'Food & Beverage', color: 'text-amber-400' },
  { value: 'maintenance', label: 'Maintenance', color: 'text-orange-400' },
  { value: 'staff', label: 'Staff', color: 'text-indigo-400' },
  { value: 'utilities', label: 'Utilities', color: 'text-cyan-400' },
  { value: 'marketing', label: 'Marketing', color: 'text-pink-400' },
  { value: 'other', label: 'Other', color: 'text-slate-400' },
];

const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

function ExpenseModal({ expense, onSave, onClose }) {
  const [form, setForm] = useState({
    description: expense?.description || '',
    amount: expense?.amount || '',
    category: expense?.category || 'other',
    expenseDate: expense?.expenseDate || format(new Date(), 'yyyy-MM-dd'),
  });
  const [error, setError] = useState('');

  const handleSave = () => {
    if (!form.description || !form.amount) { setError('Fill all required fields.'); return; }
    onSave({ ...form, amount: Number(form.amount) });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-md p-6 z-10">
        <h2 className="text-xl font-bold text-white mb-5">{expense ? 'Edit Expense' : 'Add Expense'}</h2>
        {error && <div className="mb-4 px-4 py-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">{error}</div>}
        <div className="space-y-4">
          <div>
            <label className="label">Description *</label>
            <input className="input-field" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="e.g. Kitchen supplies" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Amount (₹) *</label>
              <input type="number" min="0" className="input-field" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} placeholder="5000" />
            </div>
            <div>
              <label className="label">Date</label>
              <input type="date" className="input-field" value={form.expenseDate} onChange={e => setForm(f => ({ ...f, expenseDate: e.target.value }))} />
            </div>
          </div>
          <div>
            <label className="label">Category</label>
            <select className="input-field" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={handleSave} className="btn-primary flex-1 justify-center">Save</button>
          <button onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default function Expenses() {
  const { isAdmin } = useAuth();
  const [expenses, setExpenses] = useState([]);
  const [modal, setModal] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [filter, setFilter] = useState('all');
  const [toast, setToast] = useState('');
  const [monthFilter, setMonthFilter] = useState(format(new Date(), 'yyyy-MM'));

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };
  const load = () => setExpenses(db.expenses.getAll());
  useEffect(() => { load(); }, []);

  const filtered = expenses.filter(e => {
    const matchCat = filter === 'all' || e.category === filter;
    const matchMonth = !monthFilter || e.expenseDate.startsWith(monthFilter);
    return matchCat && matchMonth;
  }).sort((a, b) => new Date(b.expenseDate) - new Date(a.expenseDate));

  const totalFiltered = filtered.reduce((s, e) => s + Number(e.amount), 0);

  const handleSave = (data) => {
    if (modal === 'add') { db.expenses.create({ ...data, createdBy: 'current' }); showToast('Expense added!'); }
    else { db.expenses.update(modal.id, data); showToast('Expense updated!'); }
    load(); setModal(null);
  };

  const handleDelete = (id) => { db.expenses.delete(id); load(); setConfirmDelete(null); showToast('Expense deleted.'); };

  // Category breakdown
  const breakdown = CATEGORIES.map(cat => ({
    ...cat,
    total: filtered.filter(e => e.category === cat.value).reduce((s, e) => s + Number(e.amount), 0),
  })).filter(c => c.total > 0);

  const getCatInfo = (cat) => CATEGORIES.find(c => c.value === cat) || CATEGORIES[CATEGORIES.length - 1];

  return (
    <div className="space-y-6">
      {toast && <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded-xl bg-emerald-600 text-white text-sm font-medium shadow-lg">{toast}</div>}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">Expenses</h1>
          <p className="text-slate-400 text-sm mt-1">
            {isAdmin ? 'Track and manage resort expenses' : 'View expense records'}
          </p>
        </div>
        {isAdmin && (
          <button onClick={() => setModal('add')} className="btn-primary">
            <Plus className="h-4 w-4" /> Add Expense
          </button>
        )}
      </div>

      {/* Summary */}
      {isAdmin && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="stat-card">
            <div className="text-slate-400 text-sm mb-2">Total (filtered)</div>
            <div className="text-2xl font-bold text-rose-400">{fmt(totalFiltered)}</div>
          </div>
          {breakdown.slice(0, 2).map(b => (
            <div key={b.value} className="stat-card">
              <div className="text-slate-400 text-sm mb-2">{b.label}</div>
              <div className={`text-2xl font-bold ${b.color}`}>{fmt(b.total)}</div>
              <div className="text-xs text-slate-500 mt-1">{totalFiltered > 0 ? ((b.total / totalFiltered) * 100).toFixed(1) : 0}% of total</div>
            </div>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <input
          type="month"
          className="input-field sm:w-44"
          value={monthFilter}
          onChange={e => setMonthFilter(e.target.value)}
        />
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setFilter('all')} className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${filter === 'all' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-slate-700/40 text-slate-400 border-slate-600'}`}>
            All
          </button>
          {CATEGORIES.map(c => (
            <button key={c.value} onClick={() => setFilter(c.value)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${filter === c.value ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-slate-700/40 text-slate-400 border-slate-600'}`}>
              {c.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Table */}
        <div className="lg:col-span-2 card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700/50">
                  <th className="table-header">Description</th>
                  <th className="table-header">Category</th>
                  <th className="table-header">Date</th>
                  {isAdmin && <th className="table-header">Amount</th>}
                  {isAdmin && <th className="table-header text-right">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map(e => {
                  const cat = getCatInfo(e.category);
                  return (
                    <tr key={e.id} className="table-row">
                      <td className="table-cell font-medium text-white">{e.description}</td>
                      <td className="table-cell">
                        <span className={`text-xs font-medium ${cat.color}`}>{cat.label}</span>
                      </td>
                      <td className="table-cell">{format(new Date(e.expenseDate + 'T00:00:00'), 'dd MMM yyyy')}</td>
                      {isAdmin && <td className="table-cell font-medium text-rose-400">{fmt(e.amount)}</td>}
                      {isAdmin && (
                        <td className="table-cell">
                          <div className="flex items-center justify-end gap-2">
                            <button onClick={() => setModal(e)} className="p-1.5 text-slate-400 hover:text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-all">
                              <Edit className="h-4 w-4" />
                            </button>
                            <button onClick={() => setConfirmDelete(e.id)} className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="text-center py-16 text-slate-500">
                <Receipt className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>No expenses found</p>
              </div>
            )}
          </div>
        </div>

        {/* Category breakdown (admin only) */}
        {isAdmin && (
          <div className="card p-5">
            <h2 className="text-lg font-semibold text-white mb-4">Breakdown</h2>
            {breakdown.length === 0 ? (
              <p className="text-slate-500 text-sm">No data</p>
            ) : (
              <div className="space-y-3">
                {breakdown.sort((a, b) => b.total - a.total).map(cat => (
                  <div key={cat.value}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className={cat.color}>{cat.label}</span>
                      <span className="text-slate-300">{fmt(cat.total)}</span>
                    </div>
                    <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-rose-600 to-rose-400 transition-all"
                        style={{ width: totalFiltered > 0 ? `${(cat.total / totalFiltered) * 100}%` : '0%' }}
                      />
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {totalFiltered > 0 ? ((cat.total / totalFiltered) * 100).toFixed(1) : 0}%
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {modal && <ExpenseModal expense={modal === 'add' ? null : modal} onSave={handleSave} onClose={() => setModal(null)} />}

      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setConfirmDelete(null)} />
          <div className="relative card p-6 max-w-sm w-full z-10 text-center">
            <Trash2 className="h-10 w-10 text-red-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">Delete Expense?</h3>
            <div className="flex gap-3 mt-4">
              <button onClick={() => handleDelete(confirmDelete)} className="btn-danger flex-1 justify-center">Delete</button>
              <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1 justify-center">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
