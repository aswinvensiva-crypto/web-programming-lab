import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Search, Edit, Trash2, FileText, Filter } from 'lucide-react';
import { format } from 'date-fns';
import BookingReceipt from '@/components/bookings/BookingReceipt';

const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

const STATUS_OPTS = ['all', 'confirmed', 'checked_in', 'checked_out', 'cancelled'];
const PAY_OPTS = ['all', 'pending', 'partial', 'paid'];

export default function Bookings() {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [payFilter, setPayFilter] = useState('all');
  const [receiptBooking, setReceiptBooking] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [toast, setToast] = useState('');

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };
  const load = () => setBookings(db.bookings.getAll());
  useEffect(() => { load(); }, []);

  const filtered = bookings.filter(b => {
    const matchSearch = !search ||
      b.customer?.name?.toLowerCase().includes(search.toLowerCase()) ||
      b.room?.roomNumber?.includes(search) ||
      b.room?.roomName?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || b.bookingStatus === statusFilter;
    const matchPay = payFilter === 'all' || b.paymentStatus === payFilter;
    return matchSearch && matchStatus && matchPay;
  }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const handleDelete = (id) => {
    db.bookings.delete(id); load(); setConfirmDelete(null); showToast('Booking deleted.');
  };

  const statusBadge = (s) => {
    const map = { confirmed: 'badge-confirmed', checked_in: 'badge-checked_in', checked_out: 'badge-checked_out', cancelled: 'badge-cancelled' };
    return map[s] || '';
  };
  const payBadge = (s) => {
    const map = { paid: 'badge-paid', partial: 'badge-partial', pending: 'badge-pending' };
    return map[s] || '';
  };

  return (
    <div className="space-y-6">
      {toast && (
        <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded-xl bg-emerald-600 text-white text-sm font-medium shadow-lg">
          {toast}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">Bookings</h1>
          <p className="text-slate-400 text-sm mt-1">{filtered.length} bookings found</p>
        </div>
        <button onClick={() => navigate('/bookings/new')} className="btn-primary">
          <Plus className="h-4 w-4" /> New Booking
        </button>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <input className="input-field pl-10" placeholder="Search guest, room..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="input-field sm:w-44" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          {STATUS_OPTS.map(s => <option key={s} value={s}>{s === 'all' ? 'All Statuses' : s.replace('_', ' ')}</option>)}
        </select>
        <select className="input-field sm:w-44" value={payFilter} onChange={e => setPayFilter(e.target.value)}>
          {PAY_OPTS.map(s => <option key={s} value={s}>{s === 'all' ? 'All Payments' : s}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="table-header">Guest</th>
                <th className="table-header">Room</th>
                <th className="table-header">Check-in</th>
                <th className="table-header">Check-out</th>
                <th className="table-header">Days</th>
                <th className="table-header">Booking</th>
                <th className="table-header">Payment</th>
                {isAdmin && <th className="table-header">Amount</th>}
                {isAdmin && <th className="table-header">Pending</th>}
                <th className="table-header text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(b => (
                <tr key={b.id} className="table-row">
                  <td className="table-cell">
                    <div className="font-medium text-white">{b.customer?.name}</div>
                    <div className="text-xs text-slate-500">{b.customer?.phone}</div>
                  </td>
                  <td className="table-cell">
                    <div className="text-white">{b.room?.roomNumber}</div>
                    <div className="text-xs text-slate-500">{b.room?.roomName}</div>
                  </td>
                  <td className="table-cell">{format(new Date(b.checkInDate + 'T00:00:00'), 'dd MMM yy')}</td>
                  <td className="table-cell">{format(new Date(b.checkOutDate + 'T00:00:00'), 'dd MMM yy')}</td>
                  <td className="table-cell text-center">{b.totalDays}</td>
                  <td className="table-cell"><span className={statusBadge(b.bookingStatus)}>{b.bookingStatus.replace('_', ' ')}</span></td>
                  <td className="table-cell"><span className={payBadge(b.paymentStatus)}>{b.paymentStatus}</span></td>
                  {isAdmin && <td className="table-cell text-emerald-400 font-medium">{fmt(b.totalAmount)}</td>}
                  {isAdmin && <td className="table-cell text-amber-400">{fmt(b.pendingAmount)}</td>}
                  <td className="table-cell">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => setReceiptBooking(b)} className="p-1.5 text-slate-400 hover:text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-all" title="View Receipt">
                        <FileText className="h-4 w-4" />
                      </button>
                      <button onClick={() => navigate(`/bookings/${b.id}/edit`)} className="p-1.5 text-slate-400 hover:text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-all" title="Edit">
                        <Edit className="h-4 w-4" />
                      </button>
                      {isAdmin && (
                        <button onClick={() => setConfirmDelete(b.id)} className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all" title="Delete">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-16 text-slate-500">
              <FileText className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>No bookings found</p>
            </div>
          )}
        </div>
      </div>

      {/* Receipt Modal */}
      {receiptBooking && <BookingReceipt booking={receiptBooking} onClose={() => setReceiptBooking(null)} />}

      {/* Delete Confirm */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setConfirmDelete(null)} />
          <div className="relative card p-6 max-w-sm w-full z-10 text-center">
            <Trash2 className="h-10 w-10 text-red-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">Delete Booking?</h3>
            <p className="text-slate-400 text-sm mb-5">This will also free up the room.</p>
            <div className="flex gap-3">
              <button onClick={() => handleDelete(confirmDelete)} className="btn-danger flex-1 justify-center">Delete</button>
              <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1 justify-center">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
