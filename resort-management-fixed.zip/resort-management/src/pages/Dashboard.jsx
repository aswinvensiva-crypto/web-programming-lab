import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import {
  BedDouble, Users, TrendingUp, TrendingDown, Plus, DollarSign,
  Calendar, Receipt, IndianRupee, BarChart3, ArrowUpRight
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { format, subDays, startOfMonth, endOfMonth, isSameMonth } from 'date-fns';

const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

function StatCard({ title, value, sub, icon: Icon, trend, color = 'indigo' }) {
  const colors = {
    indigo: 'from-indigo-600 to-indigo-500',
    emerald: 'from-emerald-600 to-emerald-500',
    amber: 'from-amber-500 to-amber-400',
    rose: 'from-rose-600 to-rose-500',
    blue: 'from-blue-600 to-blue-500',
  };
  return (
    <div className="stat-card">
      <div className="flex items-start justify-between mb-4">
        <div className={`h-11 w-11 rounded-xl bg-gradient-to-br ${colors[color]} flex items-center justify-center shadow-lg`}>
          <Icon className="h-5 w-5 text-white" />
        </div>
        {trend !== undefined && (
          <span className={`text-xs font-medium flex items-center gap-1 ${trend >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {trend >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {Math.abs(trend).toFixed(1)}%
          </span>
        )}
      </div>
      <div className="text-2xl font-bold text-white mb-1">{value}</div>
      <div className="text-sm text-slate-400">{title}</div>
      {sub && <div className="text-xs text-slate-500 mt-1">{sub}</div>}
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [stats, setStats] = useState({});
  const [recentBookings, setRecentBookings] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [roomOccupancy, setRoomOccupancy] = useState([]);

  useEffect(() => {
    const bookings = db.bookings.getAll();
    const rooms = db.rooms.getAll();
    const expenses = db.expenses.getAll();
    const now = new Date();
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);

    // Stats
    const totalRooms = rooms.length;
    const availableRooms = rooms.filter(r => r.status === 'available').length;
    const occupiedRooms = rooms.filter(r => r.status === 'occupied').length;
    const occupancyRate = ((occupiedRooms / totalRooms) * 100).toFixed(1);

    const totalRevenue = bookings.reduce((s, b) => s + Number(b.totalAmount), 0);
    const monthRevenue = bookings
      .filter(b => new Date(b.createdAt) >= monthStart && new Date(b.createdAt) <= monthEnd)
      .reduce((s, b) => s + Number(b.totalAmount), 0);
    const monthExpenses = expenses
      .filter(e => new Date(e.expenseDate) >= monthStart && new Date(e.expenseDate) <= monthEnd)
      .reduce((s, e) => s + Number(e.amount), 0);
    const profit = monthRevenue - monthExpenses;

    const activeBookings = bookings.filter(b => ['confirmed', 'checked_in'].includes(b.bookingStatus));
    const totalCustomers = db.customers.getAll().length;

    setStats({ totalRooms, availableRooms, occupiedRooms, occupancyRate, totalRevenue, monthRevenue, monthExpenses, profit, activeBookings: activeBookings.length, totalCustomers });

    // Recent bookings
    setRecentBookings(
      [...bookings].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 6)
    );

    // Chart data — last 7 days revenue
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = subDays(now, 6 - i);
      const dayStr = format(d, 'yyyy-MM-dd');
      const rev = bookings
        .filter(b => b.createdAt.startsWith(dayStr))
        .reduce((s, b) => s + Number(b.totalAmount), 0);
      return { day: format(d, 'EEE'), revenue: rev };
    });
    setChartData(days);

    // Room category occupancy
    const categories = ['standard', 'deluxe', 'ultra_deluxe', 'suite', 'presidential'];
    const occData = categories.map(cat => {
      const catRooms = rooms.filter(r => r.category === cat);
      const occupied = catRooms.filter(r => r.status === 'occupied').length;
      return { name: cat.replace('_', ' '), total: catRooms.length, occupied };
    }).filter(d => d.total > 0);
    setRoomOccupancy(occData);
  }, []);

  const statusColor = (s) => {
    const map = { confirmed: 'badge-confirmed', checked_in: 'badge-checked_in', checked_out: 'badge-checked_out', cancelled: 'badge-cancelled' };
    return map[s] || 'badge-confirmed';
  };
  const payColor = (s) => {
    const map = { paid: 'badge-paid', partial: 'badge-partial', pending: 'badge-pending' };
    return map[s] || 'badge-pending';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400 text-sm mt-1">{format(new Date(), 'EEEE, dd MMMM yyyy')}</p>
        </div>
        <button onClick={() => navigate('/bookings/new')} className="btn-primary">
          <Plus className="h-4 w-4" /> New Booking
        </button>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Rooms" value={stats.totalRooms} sub={`${stats.availableRooms} available`} icon={BedDouble} color="indigo" />
        <StatCard title="Occupancy Rate" value={`${stats.occupancyRate}%`} sub={`${stats.occupiedRooms} occupied`} icon={BarChart3} color="amber" />
        <StatCard title="Active Bookings" value={stats.activeBookings} sub="confirmed + checked in" icon={Calendar} color="blue" />
        <StatCard title="Total Customers" value={stats.totalCustomers} sub="registered guests" icon={Users} color="emerald" />
      </div>

      {isAdmin && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Month Revenue" value={fmt(stats.monthRevenue)} icon={IndianRupee} color="emerald" />
          <StatCard title="Month Expenses" value={fmt(stats.monthExpenses)} icon={Receipt} color="rose" />
          <StatCard title="Net Profit" value={fmt(stats.profit)} icon={TrendingUp} color={stats.profit >= 0 ? 'emerald' : 'rose'} />
          <StatCard title="Total Revenue" value={fmt(stats.totalRevenue)} sub="all time" icon={DollarSign} color="indigo" />
        </div>
      )}

      {/* Charts and table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        {isAdmin && (
          <div className="lg:col-span-2 card p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Revenue — Last 7 Days</h2>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData} barSize={32}>
                <XAxis dataKey="day" tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
                <Tooltip formatter={v => [`₹${Number(v).toLocaleString('en-IN')}`, 'Revenue']} contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12 }} labelStyle={{ color: '#94a3b8' }} itemStyle={{ color: '#a5b4fc' }} />
                <Bar dataKey="revenue" radius={[6, 6, 0, 0]}>
                  {chartData.map((_, i) => <Cell key={i} fill={i === chartData.length - 1 ? '#6366f1' : '#4f46e5'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Room Category Occupancy */}
        <div className={`card p-6 ${!isAdmin ? 'lg:col-span-3' : ''}`}>
          <h2 className="text-lg font-semibold text-white mb-4">Room Categories</h2>
          <div className="space-y-3">
            {roomOccupancy.map(cat => (
              <div key={cat.name}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-300 capitalize">{cat.name}</span>
                  <span className="text-slate-500">{cat.occupied}/{cat.total}</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-600 to-indigo-400 rounded-full transition-all"
                    style={{ width: cat.total ? `${(cat.occupied / cat.total) * 100}%` : '0%' }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Bookings */}
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700/50">
          <h2 className="text-lg font-semibold text-white">Recent Bookings</h2>
          <button onClick={() => navigate('/bookings')} className="text-indigo-400 hover:text-indigo-300 text-sm flex items-center gap-1">
            View All <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="table-header">Guest</th>
                <th className="table-header">Room</th>
                <th className="table-header">Check-in</th>
                <th className="table-header">Check-out</th>
                <th className="table-header">Status</th>
                <th className="table-header">Payment</th>
                {isAdmin && <th className="table-header">Amount</th>}
              </tr>
            </thead>
            <tbody>
              {recentBookings.map(b => (
                <tr key={b.id} className="table-row cursor-pointer" onClick={() => navigate(`/bookings/${b.id}/edit`)}>
                  <td className="table-cell font-medium text-white">{b.customer?.name}</td>
                  <td className="table-cell">{b.room?.roomNumber} — {b.room?.roomName}</td>
                  <td className="table-cell">{format(new Date(b.checkInDate + 'T00:00:00'), 'dd MMM yyyy')}</td>
                  <td className="table-cell">{format(new Date(b.checkOutDate + 'T00:00:00'), 'dd MMM yyyy')}</td>
                  <td className="table-cell"><span className={statusColor(b.bookingStatus)}>{b.bookingStatus.replace('_', ' ')}</span></td>
                  <td className="table-cell"><span className={payColor(b.paymentStatus)}>{b.paymentStatus}</span></td>
                  {isAdmin && <td className="table-cell font-medium text-emerald-400">{fmt(b.totalAmount)}</td>}
                </tr>
              ))}
            </tbody>
          </table>
          {recentBookings.length === 0 && (
            <div className="text-center py-12 text-slate-500">No bookings yet</div>
          )}
        </div>
      </div>
    </div>
  );
}
