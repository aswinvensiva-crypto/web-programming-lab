import { useState, useEffect } from 'react';
import { db } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Edit, Trash2, BedDouble, Wifi, Tv, Wind, Waves, Coffee, Star } from 'lucide-react';

const CATEGORIES = [
  { value: 'standard', label: 'Standard', color: 'bg-slate-500/20 text-slate-300 border-slate-500/20' },
  { value: 'deluxe', label: 'Deluxe', color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/20' },
  { value: 'ultra_deluxe', label: 'Ultra Deluxe', color: 'bg-purple-500/20 text-purple-300 border-purple-500/20' },
  { value: 'suite', label: 'Suite', color: 'bg-amber-500/20 text-amber-300 border-amber-500/20' },
  { value: 'presidential', label: 'Presidential', color: 'bg-gradient-to-r from-indigo-500/30 to-amber-500/30 text-white border-indigo-500/30' },
];

const STATUSES = ['available', 'maintenance', 'unavailable'];
const AMENITY_ICONS = { WiFi: Wifi, TV: Tv, AC: Wind, Pool: Waves, Coffee: Coffee };

const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

function RoomModal({ room, onSave, onClose }) {
  const [form, setForm] = useState({
    roomNumber: room?.roomNumber || '',
    roomName: room?.roomName || '',
    capacity: room?.capacity || 2,
    pricePerDay: room?.pricePerDay || '',
    status: room?.status || 'available',
    category: room?.category || 'standard',
    amenities: room?.amenities || [],
  });
  const [error, setError] = useState('');

  const amenityOptions = ['AC', 'TV', 'WiFi', 'Balcony', 'Jacuzzi', 'Mini Bar', 'Kitchen', 'Sea View', 'Private Pool', 'Butler', 'Garden Access', 'Coffee Machine'];

  const toggleAmenity = (a) => {
    setForm(f => ({
      ...f,
      amenities: f.amenities.includes(a) ? f.amenities.filter(x => x !== a) : [...f.amenities, a]
    }));
  };

  const handleSave = () => {
    if (!form.roomNumber || !form.roomName || !form.pricePerDay) {
      setError('Please fill all required fields.'); return;
    }
    onSave({ ...form, capacity: Number(form.capacity), pricePerDay: Number(form.pricePerDay) });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-lg p-6 z-10 max-h-[90vh] overflow-y-auto">
        <h2 className="text-xl font-bold text-white mb-5">{room ? 'Edit Room' : 'Add New Room'}</h2>
        {error && <div className="mb-4 px-4 py-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">{error}</div>}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Room Number *</label>
            <input className="input-field" value={form.roomNumber} onChange={e => setForm(f => ({ ...f, roomNumber: e.target.value }))} placeholder="101" />
          </div>
          <div>
            <label className="label">Room Name *</label>
            <input className="input-field" value={form.roomName} onChange={e => setForm(f => ({ ...f, roomName: e.target.value }))} placeholder="Ocean Breeze" />
          </div>
          <div>
            <label className="label">Capacity</label>
            <input type="number" min="1" max="20" className="input-field" value={form.capacity} onChange={e => setForm(f => ({ ...f, capacity: e.target.value }))} />
          </div>
          <div>
            <label className="label">Price per Day (₹) *</label>
            <input type="number" min="0" className="input-field" value={form.pricePerDay} onChange={e => setForm(f => ({ ...f, pricePerDay: e.target.value }))} placeholder="3500" />
          </div>
          <div>
            <label className="label">Category</label>
            <select className="input-field" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Status</label>
            <select className="input-field" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
              {STATUSES.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-4">
          <label className="label">Amenities</label>
          <div className="flex flex-wrap gap-2">
            {amenityOptions.map(a => (
              <button key={a} type="button"
                onClick={() => toggleAmenity(a)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${form.amenities.includes(a) ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-slate-700/50 text-slate-400 border-slate-600 hover:border-indigo-500/50'}`}
              >{a}</button>
            ))}
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={handleSave} className="btn-primary flex-1 justify-center">Save Room</button>
          <button onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default function Rooms() {
  const { isAdmin } = useAuth();
  const [rooms, setRooms] = useState([]);
  const [modal, setModal] = useState(null); // null | 'add' | room object
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [toast, setToast] = useState('');

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  const load = () => setRooms(db.rooms.getAll());
  useEffect(() => { load(); }, []);

  const filtered = rooms.filter(r => {
    const matchFilter = filter === 'all' || r.status === filter || r.category === filter;
    const matchSearch = !search || r.roomNumber.toLowerCase().includes(search.toLowerCase()) || r.roomName.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const handleSave = (data) => {
    if (modal === 'add') { db.rooms.create(data); showToast('Room added successfully!'); }
    else { db.rooms.update(modal.id, data); showToast('Room updated successfully!'); }
    load(); setModal(null);
  };

  const handleDelete = (id) => {
    db.rooms.delete(id); load(); setConfirmDelete(null); showToast('Room deleted.');
  };

  const getCatStyle = (cat) => CATEGORIES.find(c => c.value === cat)?.color || '';
  const getStatusBadge = (s) => {
    const map = { available: 'badge-available', maintenance: 'badge-maintenance', occupied: 'badge-occupied', unavailable: 'badge-maintenance' };
    return map[s] || '';
  };

  const stats = {
    total: rooms.length,
    available: rooms.filter(r => r.status === 'available').length,
    occupied: rooms.filter(r => r.status === 'occupied').length,
    maintenance: rooms.filter(r => r.status === 'maintenance').length,
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded-xl bg-emerald-600 text-white text-sm font-medium shadow-lg animate-pulse">
          {toast}
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">Rooms</h1>
          <p className="text-slate-400 text-sm mt-1">Manage resort room inventory</p>
        </div>
        {isAdmin && (
          <button onClick={() => setModal('add')} className="btn-primary">
            <Plus className="h-4 w-4" /> Add Room
          </button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total', value: stats.total, color: 'text-white' },
          { label: 'Available', value: stats.available, color: 'text-emerald-400' },
          { label: 'Occupied', value: stats.occupied, color: 'text-red-400' },
          { label: 'Maintenance', value: stats.maintenance, color: 'text-amber-400' },
        ].map(s => (
          <div key={s.label} className="card p-4 text-center">
            <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-xs text-slate-400 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          className="input-field sm:w-64"
          placeholder="Search rooms..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className="flex gap-2 flex-wrap">
          {['all', 'available', 'occupied', 'maintenance', ...CATEGORIES.map(c => c.value)].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${filter === f ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-slate-700/40 text-slate-400 border-slate-600 hover:border-indigo-500/50'}`}
            >
              {f === 'all' ? 'All' : f.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Rooms Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map(room => (
          <div key={room.id} className="card p-5 hover:border-indigo-500/30 transition-all duration-300 flex flex-col gap-3">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-bold text-lg">#{room.roomNumber}</span>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${getCatStyle(room.category)}`}>
                    {CATEGORIES.find(c => c.value === room.category)?.label}
                  </span>
                </div>
                <div className="text-slate-300 text-sm">{room.roomName}</div>
              </div>
              <span className={getStatusBadge(room.status)}>{room.status}</span>
            </div>

            <div className="flex items-center gap-4 text-sm text-slate-400">
              <span className="flex items-center gap-1"><BedDouble className="h-4 w-4" /> {room.capacity} guests</span>
              <span className="text-emerald-400 font-semibold">{fmt(room.pricePerDay)}/day</span>
            </div>

            {room.amenities?.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {room.amenities.slice(0, 4).map(a => (
                  <span key={a} className="text-xs px-2 py-0.5 rounded-md bg-slate-700/60 text-slate-400">{a}</span>
                ))}
                {room.amenities.length > 4 && (
                  <span className="text-xs px-2 py-0.5 rounded-md bg-slate-700/60 text-slate-500">+{room.amenities.length - 4}</span>
                )}
              </div>
            )}

            {isAdmin && (
              <div className="flex gap-2 pt-2 border-t border-slate-700/50">
                <button onClick={() => setModal(room)} className="btn-secondary flex-1 justify-center py-1.5 text-xs">
                  <Edit className="h-3.5 w-3.5" /> Edit
                </button>
                <button onClick={() => setConfirmDelete(room.id)} className="btn-danger flex-1 justify-center py-1.5 text-xs">
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-slate-500">
          <BedDouble className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p>No rooms found</p>
        </div>
      )}

      {/* Add/Edit Modal */}
      {modal && <RoomModal room={modal === 'add' ? null : modal} onSave={handleSave} onClose={() => setModal(null)} />}

      {/* Delete Confirm */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setConfirmDelete(null)} />
          <div className="relative card p-6 max-w-sm w-full z-10 text-center">
            <Trash2 className="h-10 w-10 text-red-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">Delete Room?</h3>
            <p className="text-slate-400 text-sm mb-5">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => handleDelete(confirmDelete)} className="btn-danger flex-1 justify-center">Delete</button>
              <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1 justify-center">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
