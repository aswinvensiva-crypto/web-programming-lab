import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { db } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { differenceInDays } from 'date-fns';
import { ArrowLeft, Save } from 'lucide-react';
import BookingReceipt from '@/components/bookings/BookingReceipt';

const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

export default function EditBooking() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [booking, setBooking] = useState(null);
  const [rooms, setRooms] = useState([]);
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);
  const [toast, setToast] = useState('');
  const [error, setError] = useState('');

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  useEffect(() => {
    const b = db.bookings.getById(id);
    if (!b) { navigate('/bookings'); return; }
    setBooking(b);
    setRooms(db.rooms.getAll());
    setForm({
      checkInDate: b.checkInDate,
      checkOutDate: b.checkOutDate,
      roomId: b.roomId,
      bookingStatus: b.bookingStatus,
      paymentStatus: b.paymentStatus,
      taxPercentage: String(b.taxPercentage || 0),
      advancePaid: String(b.advancePaid || 0),
      notes: b.notes || '',
    });
  }, [id]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const calc = () => {
    if (!form?.checkInDate || !form?.checkOutDate || !form?.roomId) return { days: 0, base: 0, tax: 0, total: 0, pending: 0 };
    const days = differenceInDays(new Date(form.checkOutDate), new Date(form.checkInDate));
    if (days <= 0) return { days: 0, base: 0, tax: 0, total: 0, pending: 0 };
    const room = rooms.find(r => r.id === form.roomId);
    const base = days * (room?.pricePerDay || 0);
    const tax = base * (Number(form.taxPercentage) / 100);
    const total = base + tax;
    const pending = Math.max(0, total - Number(form.advancePaid));
    return { days, base, tax, total, pending };
  };

  const { days, base, tax, total, pending } = calc();

  const handleSave = (e) => {
    e.preventDefault();
    setError('');
    if (days <= 0) { setError('Check-out must be after check-in.'); return; }
    setLoading(true);
    db.bookings.update(id, {
      checkInDate: form.checkInDate, checkOutDate: form.checkOutDate,
      roomId: form.roomId, bookingStatus: form.bookingStatus,
      totalDays: days, baseAmount: base, taxPercentage: Number(form.taxPercentage),
      taxAmount: tax, totalAmount: total, advancePaid: Number(form.advancePaid),
      notes: form.notes,
    });
    setLoading(false);
    showToast('Booking updated successfully!');
    const updated = db.bookings.getById(id);
    setBooking(updated);
  };

  if (!booking || !form) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin h-8 w-8 rounded-full border-2 border-indigo-500 border-t-transparent" />
    </div>
  );

  const availableRooms = rooms.filter(r => r.status === 'available' || r.id === booking.roomId);

  return (
    <div className="space-y-6 max-w-3xl">
      {toast && <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded-xl bg-emerald-600 text-white text-sm font-medium shadow-lg">{toast}</div>}

      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/bookings')} className="btn-secondary p-2">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-white">Edit Booking</h1>
          <p className="text-slate-400 text-sm mt-0.5">{booking.customer?.name} · Room {booking.room?.roomNumber}</p>
        </div>
        <button onClick={() => setShowReceipt(true)} className="ml-auto btn-secondary text-sm">View Receipt</button>
      </div>

      {error && <div className="px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">{error}</div>}

      <form onSubmit={handleSave} className="space-y-5">
        {/* Guest Info (read-only) */}
        <div className="card p-5">
          <h2 className="text-lg font-semibold text-white mb-4">Guest Information</h2>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-slate-500 text-xs mb-1">Name</div>
              <div className="text-white font-medium">{booking.customer?.name}</div>
            </div>
            <div>
              <div className="text-slate-500 text-xs mb-1">Phone</div>
              <div className="text-white">{booking.customer?.phone}</div>
            </div>
            {booking.customer?.email && (
              <div>
                <div className="text-slate-500 text-xs mb-1">Email</div>
                <div className="text-white">{booking.customer?.email}</div>
              </div>
            )}
            {booking.customer?.address && (
              <div>
                <div className="text-slate-500 text-xs mb-1">Address</div>
                <div className="text-white">{booking.customer?.address}</div>
              </div>
            )}
          </div>
        </div>

        {/* Room & Dates */}
        <div className="card p-5 space-y-4">
          <h2 className="text-lg font-semibold text-white">Room & Dates</h2>
          <div>
            <label className="label">Room</label>
            <select className="input-field" value={form.roomId} onChange={e => set('roomId', e.target.value)} disabled={!isAdmin}>
              {availableRooms.map(r => (
                <option key={r.id} value={r.id}>#{r.roomNumber} — {r.roomName} — {fmt(r.pricePerDay)}/day</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Check-in</label>
              <input type="date" className="input-field" value={form.checkInDate} onChange={e => set('checkInDate', e.target.value)} />
            </div>
            <div>
              <label className="label">Check-out</label>
              <input type="date" className="input-field" value={form.checkOutDate} onChange={e => set('checkOutDate', e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Booking Status</label>
              <select className="input-field" value={form.bookingStatus} onChange={e => set('bookingStatus', e.target.value)}>
                {['confirmed', 'checked_in', 'checked_out', 'cancelled'].map(s => (
                  <option key={s} value={s}>{s.replace('_', ' ')}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Notes</label>
              <input className="input-field" value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="Special requests..." />
            </div>
          </div>
        </div>

        {/* Payment */}
        {isAdmin && (
          <div className="card p-5 space-y-4">
            <h2 className="text-lg font-semibold text-white">Payment</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Tax (%)</label>
                <input type="number" min="0" max="100" className="input-field" value={form.taxPercentage} onChange={e => set('taxPercentage', e.target.value)} />
              </div>
              <div>
                <label className="label">Advance Paid (₹)</label>
                <input type="number" min="0" className="input-field" value={form.advancePaid} onChange={e => set('advancePaid', e.target.value)} />
              </div>
            </div>
            {days > 0 && (
              <div className="bg-slate-900/60 rounded-xl p-4 space-y-2 text-sm border border-slate-700/50">
                <div className="flex justify-between text-slate-400"><span>Room × {days} nights</span><span>{fmt(base)}</span></div>
                {Number(form.taxPercentage) > 0 && <div className="flex justify-between text-slate-400"><span>Tax ({form.taxPercentage}%)</span><span>{fmt(tax)}</span></div>}
                <div className="flex justify-between font-semibold text-white border-t border-slate-700 pt-2"><span>Total</span><span>{fmt(total)}</span></div>
                <div className="flex justify-between text-emerald-400"><span>Advance</span><span>- {fmt(Number(form.advancePaid))}</span></div>
                <div className={`flex justify-between font-bold border-t border-slate-700 pt-2 ${pending > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  <span>Balance</span><span>{fmt(pending)}</span>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="flex gap-3">
          <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center py-3">
            <Save className="h-4 w-4" /> Save Changes
          </button>
          <button type="button" onClick={() => navigate('/bookings')} className="btn-secondary px-6">Cancel</button>
        </div>
      </form>

      {showReceipt && <BookingReceipt booking={booking} onClose={() => setShowReceipt(false)} />}
    </div>
  );
}
