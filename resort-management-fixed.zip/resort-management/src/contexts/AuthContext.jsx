import { createContext, useContext, useState, useEffect } from 'react';
import { db } from '@/lib/store';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const current = db.auth.currentUser();
    setUser(current);
    setLoading(false);
  }, []);

  const signIn = (email, password) => {
    const result = db.auth.login(email, password);
    if (result.user) setUser(result.user);
    return result;
  };

  const signOut = () => {
    db.auth.logout();
    setUser(null);
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signOut, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be inside AuthProvider');
  return ctx;
}
