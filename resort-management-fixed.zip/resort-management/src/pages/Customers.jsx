import { useState, useEffect } from 'react';
import { db } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Search, Edit, Trash2, Users, Phone, Mail, MapPin, BookOpen } from 'lucide-react';

export default function Customers() {
  const { isAdmin } = useAuth();
  const [customers, setCustomers] = useState([]);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [toast, setToast] = useState('');
  const [viewCustomer, setViewCustomer] = useState(null);
  const [customerBookings, setCustomerBookings] = useState([]);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };
  const load = () => setCustomers(db.customers.getAll());
  useEffect(() => { load(); }, []);

  const filtered = customers.filter(c =>
    !search ||
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search) ||
    c.email?.toLowerCase().includes(search.toLowerCase())
  );

  const handleSave = (form) => {
    if (!form.name || !form.phone) return;
    if (modal === 'add') { db.customers.create(form); showToast('Customer added!'); }
    else { db.customers.update(modal.id, form); showToast('Customer updated!'); }
    load(); setModal(null);
  };

  const handleDelete = (id) => {
    db.customers.delete(id); load(); setConfirmDelete(null); showToast('Customer deleted.');
  };

  const handleViewCustomer = (c) => {
    setViewCustomer(c);
    const bookings = db.bookings.getAll().filter(b => b.customerId === c.id);
    setCustomerBookings(bookings);
  };

  const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

  return (
    <div className="space-y-6">
      {toast && <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded-xl bg-emerald-600 text-white text-sm font-medium shadow-lg">{toast}</div>}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">Customers</h1>
          <p className="text-slate-400 text-sm mt-1">{customers.length} registered guests</p>
        </div>
        <button onClick={() => setModal('add')} className="btn-primary">
          <Plus className="h-4 w-4" /> Add Customer
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
        <input className="input-field pl-10" placeholder="Search customers..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(c => {
          const bookingCount = db.bookings.getAll().filter(b => b.customerId === c.id).length;
          return (
            <div key={c.id} className="card p-5 hover:border-indigo-500/30 transition-all duration-300">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    {c.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="font-semibold text-white">{c.name}</div>
                    <div className="text-xs text-slate-500">{bookingCount} booking{bookingCount !== 1 ? 's' : ''}</div>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5 text-sm mb-4">
                <div className="flex items-center gap-2 text-slate-400">
                  <Phone className="h-3.5 w-3.5 text-slate-600" /> {c.phone}
                </div>
                {c.email && (
                  <div className="flex items-center gap-2 text-slate-400">
                    <Mail className="h-3.5 w-3.5 text-slate-600" /> {c.email}
                  </div>
                )}
                {c.address && (
                  <div className="flex items-center gap-2 text-slate-400">
                    <MapPin className="h-3.5 w-3.5 text-slate-600" /> {c.address}
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-3 border-t border-slate-700/50">
                <button onClick={() => handleViewCustomer(c)} className="btn-secondary flex-1 justify-center py-1.5 text-xs">
                  <BookOpen className="h-3.5 w-3.5" /> History
                </button>
                <button onClick={() => setModal(c)} className="btn-secondary flex-1 justify-center py-1.5 text-xs">
                  <Edit className="h-3.5 w-3.5" /> Edit
                </button>
                {isAdmin && (
                  <button onClick={() => setConfirmDelete(c.id)} className="btn-danger px-3 py-1.5 text-xs">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-slate-500">
          <Users className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p>No customers found</p>
        </div>
      )}

      {/* Add/Edit Modal */}
      {modal && <CustomerModal customer={modal === 'add' ? null : modal} onSave={handleSave} onClose={() => setModal(null)} />}

      {/* History Modal */}
      {viewCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setViewCustomer(null)} />
          <div className="relative card w-full max-w-lg p-6 z-10 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-xl font-bold text-white">{viewCustomer.name}</h2>
                <p className="text-slate-400 text-sm">{viewCustomer.phone}</p>
              </div>
              <button onClick={() => setViewCustomer(null)} className="text-slate-400 hover:text-white text-xl">×</button>
            </div>
            <h3 className="text-sm font-medium text-slate-400 mb-3">Booking History</h3>
            {customerBookings.length === 0 ? (
              <p className="text-slate-500 text-sm">No bookings yet.</p>
            ) : (
              <div className="space-y-3">
                {customerBookings.map(b => (
                  <div key={b.id} className="p-3 rounded-xl bg-slate-700/30 border border-slate-700/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-medium text-white text-sm">Room {b.room?.roomNumber} — {b.room?.roomName}</div>
                        <div className="text-xs text-slate-400 mt-1">{b.checkInDate} → {b.checkOutDate} ({b.totalDays} nights)</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-emerald-400">{fmt(b.totalAmount)}</div>
                        <div className="text-xs text-slate-500 capitalize mt-0.5">{b.bookingStatus.replace('_', ' ')}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setConfirmDelete(null)} />
          <div className="relative card p-6 max-w-sm w-full z-10 text-center">
            <Trash2 className="h-10 w-10 text-red-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">Delete Customer?</h3>
            <p className="text-slate-400 text-sm mb-5">Their booking history will also be lost.</p>
            <div className="flex gap-3">
              <button onClick={() => handleDelete(confirmDelete)} className="btn-danger flex-1 justify-center">Delete</button>
              <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1 justify-center">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CustomerModal({ customer, onSave, onClose }) {
  const [form, setForm] = useState({
    name: customer?.name || '',
    phone: customer?.phone || '',
    email: customer?.email || '',
    address: customer?.address || '',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-md p-6 z-10">
        <h2 className="text-xl font-bold text-white mb-5">{customer ? 'Edit Customer' : 'Add Customer'}</h2>
        <div className="space-y-4">
          <div>
            <label className="label">Full Name *</label>
            <input className="input-field" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Ramesh Kumar" />
          </div>
          <div>
            <label className="label">Phone *</label>
            <input className="input-field" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="9876543210" />
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" className="input-field" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="guest@email.com" />
          </div>
          <div>
            <label className="label">Address</label>
            <input className="input-field" value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="City, State" />
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={() => onSave(form)} className="btn-primary flex-1 justify-center">Save</button>
          <button onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
        </div>
      </div>
    </div>
  );
}
