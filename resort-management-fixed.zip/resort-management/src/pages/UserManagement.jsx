import { useState, useEffect } from 'react';
import { db } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { ShieldCheck, Shield, UserPlus, Trash2, Users } from 'lucide-react';
import { format } from 'date-fns';

export default function UserManagement() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ email: '', password: '', role: 'staff' });
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(null);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };
  const load = () => setUsers(db.users.getAll());
  useEffect(() => { load(); }, []);

  const handleCreate = () => {
    setError('');
    if (!form.email || !form.password) { setError('Email and password required.'); return; }
    const result = db.users.create(form);
    if (result.error) { setError(result.error); return; }
    load(); setModal(false); setForm({ email: '', password: '', role: 'staff' });
    showToast('User created successfully!');
  };

  const handleRoleChange = (id, role) => {
    db.users.updateRole(id, role); load();
    showToast(`Role updated to ${role}`);
  };

  const handleDelete = (id) => {
    db.users.delete(id); load(); setConfirmDelete(null);
    showToast('User deleted.');
  };

  const roleColor = (r) => r === 'admin'
    ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/20'
    : 'bg-slate-500/20 text-slate-300 border-slate-500/20';

  return (
    <div className="space-y-6">
      {toast && <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded-xl bg-emerald-600 text-white text-sm font-medium shadow-lg">{toast}</div>}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">User Management</h1>
          <p className="text-slate-400 text-sm mt-1">Manage staff accounts and roles</p>
        </div>
        <button onClick={() => setModal(true)} className="btn-primary">
          <UserPlus className="h-4 w-4" /> Add User
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card p-4 text-center">
          <div className="text-2xl font-bold text-white">{users.length}</div>
          <div className="text-xs text-slate-400 mt-1">Total Users</div>
        </div>
        <div className="card p-4 text-center">
          <div className="text-2xl font-bold text-indigo-400">{users.filter(u => u.role === 'admin').length}</div>
          <div className="text-xs text-slate-400 mt-1">Admins</div>
        </div>
        <div className="card p-4 text-center">
          <div className="text-2xl font-bold text-slate-300">{users.filter(u => u.role === 'staff').length}</div>
          <div className="text-xs text-slate-400 mt-1">Staff</div>
        </div>
      </div>

      {/* Users Table */}
      <div className="card overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-700/50 flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-indigo-400" />
          <h2 className="text-lg font-semibold text-white">Users & Roles</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="table-header">User</th>
                <th className="table-header">Role</th>
                <th className="table-header">Joined</th>
                <th className="table-header">Change Role</th>
                <th className="table-header text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="table-row">
                  <td className="table-cell">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                        {u.email.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium text-white text-sm">{u.email}</div>
                        {u.id === currentUser?.id && (
                          <div className="text-xs text-indigo-400">You</div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="table-cell">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium border ${roleColor(u.role)}`}>
                      <Shield className="h-3 w-3" /> {u.role}
                    </span>
                  </td>
                  <td className="table-cell text-slate-400">
                    {format(new Date(u.createdAt), 'dd MMM yyyy')}
                  </td>
                  <td className="table-cell">
                    <select
                      value={u.role}
                      onChange={e => handleRoleChange(u.id, e.target.value)}
                      className="input-field py-1 text-sm w-32"
                      disabled={u.id === currentUser?.id}
                    >
                      <option value="admin">Admin</option>
                      <option value="staff">Staff</option>
                    </select>
                  </td>
                  <td className="table-cell">
                    <div className="flex justify-end">
                      <button
                        onClick={() => setConfirmDelete(u.id)}
                        disabled={u.id === currentUser?.id}
                        className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                        title={u.id === currentUser?.id ? 'Cannot delete yourself' : 'Delete user'}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Access Control Info */}
      <div className="card p-5">
        <h2 className="text-lg font-semibold text-white mb-4">Access Control</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
          <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
            <div className="flex items-center gap-2 mb-3">
              <ShieldCheck className="h-4 w-4 text-indigo-400" />
              <span className="font-semibold text-indigo-300">Admin Access</span>
            </div>
            <ul className="space-y-1.5 text-slate-400">
              {['Full dashboard with revenue & profit', 'Add/edit/delete rooms', 'View all financial data', 'Manage expenses (add/edit/delete)', 'Delete bookings', 'User management & role assignment'].map(item => (
                <li key={item} className="flex items-start gap-2">
                  <span className="text-indigo-500 mt-0.5">✓</span> {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="p-4 rounded-xl bg-slate-700/30 border border-slate-700/50">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="h-4 w-4 text-slate-400" />
              <span className="font-semibold text-slate-300">Staff Access</span>
            </div>
            <ul className="space-y-1.5 text-slate-400">
              {['Dashboard (occupancy only)', 'View rooms (no add/delete)', 'Create & edit bookings', 'View customer records', 'View expense records only', 'Calendar view'].map(item => (
                <li key={item} className="flex items-start gap-2">
                  <span className="text-slate-500 mt-0.5">✓</span> {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Create User Modal */}
      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setModal(false)} />
          <div className="relative card w-full max-w-md p-6 z-10">
            <h2 className="text-xl font-bold text-white mb-5">Create New User</h2>
            {error && <div className="mb-4 px-4 py-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">{error}</div>}
            <div className="space-y-4">
              <div>
                <label className="label">Email *</label>
                <input type="email" className="input-field" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="newstaff@resort.com" />
              </div>
              <div>
                <label className="label">Password *</label>
                <input type="password" className="input-field" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} placeholder="Min 6 characters" />
              </div>
              <div>
                <label className="label">Role</label>
                <select className="input-field" value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
                  <option value="staff">Staff</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={handleCreate} className="btn-primary flex-1 justify-center">Create User</button>
              <button onClick={() => setModal(false)} className="btn-secondary flex-1 justify-center">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setConfirmDelete(null)} />
          <div className="relative card p-6 max-w-sm w-full z-10 text-center">
            <Trash2 className="h-10 w-10 text-red-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">Delete User?</h3>
            <p className="text-slate-400 text-sm mb-5">This cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => handleDelete(confirmDelete)} className="btn-danger flex-1 justify-center">Delete</button>
              <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1 justify-center">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
