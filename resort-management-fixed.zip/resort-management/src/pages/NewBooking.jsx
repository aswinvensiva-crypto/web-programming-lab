import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { differenceInDays } from 'date-fns';
import { ArrowLeft, Plus, Calculator } from 'lucide-react';
import BookingReceipt from '@/components/bookings/BookingReceipt';

const fmt = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

export default function NewBooking() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [rooms, setRooms] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [newCustomer, setNewCustomer] = useState(false);
  const [loading, setLoading] = useState(false);
  const [receiptData, setReceiptData] = useState(null);
  const [error, setError] = useState('');

  const [form, setForm] = useState({
    customerId: '', roomId: '', checkInDate: '', checkOutDate: '',
    taxPercentage: '0', advancePaid: '0', notes: '', bookingStatus: 'confirmed',
    customerName: '', customerPhone: '', customerEmail: '', customerAddress: '',
  });

  useEffect(() => {
    setRooms(db.rooms.getAll().filter(r => r.status === 'available'));
    setCustomers(db.customers.getAll());
  }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const calc = () => {
    if (!form.checkInDate || !form.checkOutDate || !form.roomId) return { days: 0, base: 0, tax: 0, total: 0, pending: 0 };
    const days = differenceInDays(new Date(form.checkOutDate), new Date(form.checkInDate));
    if (days <= 0) return { days: 0, base: 0, tax: 0, total: 0, pending: 0 };
    const room = rooms.find(r => r.id === form.roomId);
    const base = days * (room?.pricePerDay || 0);
    const tax = base * (Number(form.taxPercentage) / 100);
    const total = base + tax;
    const pending = Math.max(0, total - Number(form.advancePaid));
    return { days, base, tax, total, pending };
  };

  const { days, base, tax, total, pending } = calc();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (days <= 0) { setError('Check-out must be after check-in.'); return; }
    if (!form.roomId) { setError('Please select a room.'); return; }
    if (!newCustomer && !form.customerId) { setError('Please select a customer.'); return; }
    if (newCustomer && (!form.customerName || !form.customerPhone)) { setError('Customer name and phone are required.'); return; }

    setLoading(true);
    let customerId = form.customerId;
    if (newCustomer) {
      const c = db.customers.create({ name: form.customerName, phone: form.customerPhone, email: form.customerEmail, address: form.customerAddress });
      customerId = c.id;
    }

    const booking = db.bookings.create({
      customerId, roomId: form.roomId,
      checkInDate: form.checkInDate, checkOutDate: form.checkOutDate,
      totalDays: days, baseAmount: base, taxPercentage: Number(form.taxPercentage),
      taxAmount: tax, totalAmount: total, advancePaid: Number(form.advancePaid),
      pendingAmount: pending, notes: form.notes, bookingStatus: form.bookingStatus,
      createdBy: user?.id,
    });

    const full = db.bookings.getById(booking.id);
    setReceiptData(full);
    setLoading(false);
  };

  if (receiptData) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="px-3 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-sm font-medium">
            ✓ Booking Created Successfully!
          </div>
        </div>
        <BookingReceipt booking={receiptData} onClose={() => navigate('/bookings')} />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/bookings')} className="btn-secondary p-2">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-white">New Booking</h1>
          <p className="text-slate-400 text-sm mt-0.5">Create a new room reservation</p>
        </div>
      </div>

      {error && <div className="px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">{error}</div>}

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Customer */}
        <div className="card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">Guest Information</h2>
            <button type="button" onClick={() => setNewCustomer(!newCustomer)}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
              {newCustomer ? 'Select existing' : <><Plus className="h-3 w-3" /> New customer</>}
            </button>
          </div>

          {!newCustomer ? (
            <div>
              <label className="label">Select Customer *</label>
              <select className="input-field" value={form.customerId} onChange={e => set('customerId', e.target.value)} required>
                <option value="">Choose a guest...</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.name} — {c.phone}</option>)}
              </select>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="label">Full Name *</label>
                <input className="input-field" value={form.customerName} onChange={e => set('customerName', e.target.value)} placeholder="Ramesh Kumar" />
              </div>
              <div>
                <label className="label">Phone *</label>
                <input className="input-field" value={form.customerPhone} onChange={e => set('customerPhone', e.target.value)} placeholder="9876543210" />
              </div>
              <div>
                <label className="label">Email</label>
                <input type="email" className="input-field" value={form.customerEmail} onChange={e => set('customerEmail', e.target.value)} placeholder="guest@example.com" />
              </div>
              <div>
                <label className="label">Address</label>
                <input className="input-field" value={form.customerAddress} onChange={e => set('customerAddress', e.target.value)} placeholder="City, State" />
              </div>
            </div>
          )}
        </div>

        {/* Room & Dates */}
        <div className="card p-5 space-y-4">
          <h2 className="text-lg font-semibold text-white">Room & Dates</h2>
          <div>
            <label className="label">Select Room *</label>
            <select className="input-field" value={form.roomId} onChange={e => set('roomId', e.target.value)} required>
              <option value="">Choose a room...</option>
              {rooms.map(r => (
                <option key={r.id} value={r.id}>
                  #{r.roomNumber} — {r.roomName} ({r.category.replace('_', ' ')}) — {fmt(r.pricePerDay)}/day
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Check-in Date *</label>
              <input type="date" className="input-field" value={form.checkInDate} onChange={e => set('checkInDate', e.target.value)} required />
            </div>
            <div>
              <label className="label">Check-out Date *</label>
              <input type="date" className="input-field" value={form.checkOutDate} onChange={e => set('checkOutDate', e.target.value)} required />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Booking Status</label>
              <select className="input-field" value={form.bookingStatus} onChange={e => set('bookingStatus', e.target.value)}>
                <option value="confirmed">Confirmed</option>
                <option value="checked_in">Checked In</option>
              </select>
            </div>
            <div>
              <label className="label">Notes</label>
              <input className="input-field" value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="Special requests..." />
            </div>
          </div>
        </div>

        {/* Payment */}
        <div className="card p-5 space-y-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <Calculator className="h-5 w-5 text-indigo-400" /> Payment Details
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Tax (%)</label>
              <input type="number" min="0" max="100" className="input-field" value={form.taxPercentage} onChange={e => set('taxPercentage', e.target.value)} />
            </div>
            <div>
              <label className="label">Advance Paid (₹)</label>
              <input type="number" min="0" className="input-field" value={form.advancePaid} onChange={e => set('advancePaid', e.target.value)} />
            </div>
          </div>

          {/* Bill Summary */}
          {days > 0 && (
            <div className="bg-slate-900/60 rounded-xl p-4 space-y-2 text-sm border border-slate-700/50">
              <div className="flex justify-between text-slate-400">
                <span>Room × {days} night{days > 1 ? 's' : ''}</span>
                <span>{fmt(base)}</span>
              </div>
              {Number(form.taxPercentage) > 0 && (
                <div className="flex justify-between text-slate-400">
                  <span>Tax ({form.taxPercentage}%)</span>
                  <span>{fmt(tax)}</span>
                </div>
              )}
              <div className="flex justify-between font-semibold text-white border-t border-slate-700 pt-2">
                <span>Total</span><span>{fmt(total)}</span>
              </div>
              <div className="flex justify-between text-emerald-400">
                <span>Advance Paid</span><span>- {fmt(Number(form.advancePaid))}</span>
              </div>
              <div className={`flex justify-between font-bold text-base border-t border-slate-700 pt-2 ${pending > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                <span>Balance Due</span><span>{fmt(pending)}</span>
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-3">
          <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center py-3 disabled:opacity-50">
            {loading ? <div className="animate-spin h-4 w-4 rounded-full border-2 border-white border-t-transparent" /> : 'Create Booking'}
          </button>
          <button type="button" onClick={() => navigate('/bookings')} className="btn-secondary px-6">Cancel</button>
        </div>
      </form>
    </div>
  );
}
