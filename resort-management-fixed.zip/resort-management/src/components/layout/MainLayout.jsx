import { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import {
  Home, BedDouble, CalendarDays, Users, Receipt, ShieldCheck,
  LogOut, Menu, X, Sparkles, BookOpen, ChevronLeft, ChevronRight
} from 'lucide-react';

const navItems = [
  { to: '/', icon: Home, label: 'Dashboard', adminOnly: false },
  { to: '/bookings', icon: BookOpen, label: 'Bookings', adminOnly: false },
  { to: '/calendar', icon: CalendarDays, label: 'Calendar', adminOnly: false },
  { to: '/rooms', icon: BedDouble, label: 'Rooms', adminOnly: false },
  { to: '/customers', icon: Users, label: 'Customers', adminOnly: false },
  { to: '/expenses', icon: Receipt, label: 'Expenses', adminOnly: false },
  { to: '/users', icon: ShieldCheck, label: 'User Management', adminOnly: true },
];

export default function MainLayout() {
  const { user, signOut, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSignOut = () => { signOut(); navigate('/auth'); };

  const visibleItems = navItems.filter(item => !item.adminOnly || isAdmin);

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={`flex items-center gap-3 px-4 py-5 border-b border-slate-700/50 ${collapsed ? 'justify-center' : ''}`}>
        <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-indigo-600 to-amber-500 flex items-center justify-center shadow-lg flex-shrink-0">
          <Sparkles className="h-5 w-5 text-white" />
        </div>
        {!collapsed && (
          <div>
            <div className="font-display font-bold text-white text-sm leading-tight">RESORT</div>
            <div className="text-xs text-indigo-400 font-medium">MANAGEMENT</div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {visibleItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `sidebar-link ${isActive ? 'active' : ''} ${collapsed ? 'justify-center px-2' : ''}`
            }
            title={collapsed ? label : ''}
            onClick={() => setMobileOpen(false)}
          >
            <Icon className="h-5 w-5 flex-shrink-0" />
            {!collapsed && <span>{label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* User footer */}
      <div className="border-t border-slate-700/50 p-3">
        <div className={`flex items-center gap-3 px-3 py-2 rounded-xl bg-slate-700/40 ${collapsed ? 'justify-center' : ''}`}>
          <div className="h-8 w-8 rounded-full bg-indigo-600 flex items-center justify-center flex-shrink-0 text-sm font-bold text-white">
            {user?.email?.[0]?.toUpperCase()}
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white truncate">{user?.email}</div>
              <div className="text-xs text-indigo-400 capitalize">{user?.role}</div>
            </div>
          )}
          {!collapsed && (
            <button onClick={handleSignOut} className="text-slate-400 hover:text-red-400 transition-colors p-1" title="Sign out">
              <LogOut className="h-4 w-4" />
            </button>
          )}
        </div>
        {collapsed && (
          <button onClick={handleSignOut} className="mt-2 w-full flex justify-center text-slate-400 hover:text-red-400 transition-colors py-1" title="Sign out">
            <LogOut className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-slate-900 overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className={`hidden md:flex flex-col bg-slate-900 border-r border-slate-700/50 transition-all duration-300 relative ${collapsed ? 'w-16' : 'w-60'}`}>
        <SidebarContent />
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-16 h-6 w-6 bg-slate-700 border border-slate-600 rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:bg-indigo-600 transition-all z-10"
        >
          {collapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronLeft className="h-3 w-3" />}
        </button>
      </aside>

      {/* Mobile Sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-64 bg-slate-900 border-r border-slate-700/50 z-10">
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header */}
        <header className="md:hidden flex items-center justify-between px-4 py-3 border-b border-slate-700/50 bg-slate-900">
          <button onClick={() => setMobileOpen(true)} className="text-slate-400 hover:text-white">
            <Menu className="h-6 w-6" />
          </button>
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-indigo-600 to-amber-500 flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <span className="font-display font-bold text-white text-sm">Resort Manager</span>
          </div>
          <button onClick={handleSignOut} className="text-slate-400 hover:text-red-400">
            <LogOut className="h-5 w-5" />
          </button>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
